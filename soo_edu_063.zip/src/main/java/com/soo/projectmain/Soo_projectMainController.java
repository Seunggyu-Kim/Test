package com.soo.projectmain;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

import com.soo.projectboard.Soo_projectBoardVO;

import jdk.internal.org.jline.utils.Log;


@Controller
public class Soo_projectMainController {
	
	@Resource(name = "Soo_projectMainService")
	private Soo_projectMainService service;
	
	
	
	// 메인페이지..
	@RequestMapping(value = "/soo_project_main/soo_project_main.do")
	public String soo_project_main(ModelMap model, Soo_projectMainVO vo) throws Exception {
		
		System.out.println("--------메인입니다---------");
		
		return "views/sooproject_main";
	}
	
	// 과제 2번 
	@RequestMapping(value = "/pop/pop2")
	public String pop() throws Exception{
		
		return "views/pop/pop2";
	}
	
	// 과제 3번
	@RequestMapping(value = "/soo_project01/board_list")
	public String list() throws Exception{
		
		return "views/soo_project01/board_list";
	}
	
	// 게시판 메인
	@RequestMapping(value = "/board/Soo_Edu_Main")
	public String board2Main() throws Exception{
		
		return "views/board/Soo_Edu_Main";
	}
	
}
