package com.soo.projectmain;

public class Soo_projectMainVO {
	
	private String seq;
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}	
	

}
