package com.soo.projectmain;

import java.util.List;

import org.springframework.stereotype.Service;

@Service("Soo_projectMainController")
public interface Soo_projectMainService {
	
	int test(Soo_projectMainVO vo) throws Exception;



}
