package com.soo.projectboard;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;


@Service("Soo_projectBoardService")
public class Soo_projectBoardServiceImpl implements Soo_projectBoardService {

	@Resource
	Soo_projectBoardDAO SooprojectBoardDAO;
	
	
	  //리스트
		/*
		 * @Override public List<Soo_projectBoardVO> selectBoardList(Map<String, Object>
		 * map ) throws Exception {
		 * 
		 * return SooprojectBoardDAO.selectBoardList(map); }
		 */
	 
	
	
	//QnA List............
//	@Override
//	public List<Soo_projectBoardVO> BoardList() throws Exception {
//		
//			return SooprojectBoardDAO.BoardList();
//		}
	
	//QnA Insert..........
	@Override
	public String QnAInsert(Soo_projectBoardVO vo) throws Exception {
		
			return SooprojectBoardDAO.QnAInsert(vo);
			
	}

	//QnAView...........
	@Override
	public Soo_projectBoardVO get(Long board_seq) throws Exception {

		return SooprojectBoardDAO.QnAview(board_seq);
	}

	//QnARemove.........
	@Override
	public int remove(Integer board_seq) throws Exception {

		return SooprojectBoardDAO.remove(board_seq);
	}

	@Override
	public int postupdate(Soo_projectBoardVO vo) throws Exception {
	
		System.out.println("업데이트 서비스!!");
		
		return SooprojectBoardDAO.postupdate(vo);
	}

	@Override
	public List<Soo_projectBoardVO> BoardList(Criteria cri) throws Exception {

	//	System.out.println("페이징 서비스!!!!!");
		
		return SooprojectBoardDAO.BoardList(cri);
	}

	@Override
	public int countBoardListTotal() throws Exception {

		//System.out.println("서비스 들어왔다!! ");
		
		return SooprojectBoardDAO.countBoardList();
	}

	@Override
	public String test() {

		String test="테스트입니다.";
		
		return test;
	}


}