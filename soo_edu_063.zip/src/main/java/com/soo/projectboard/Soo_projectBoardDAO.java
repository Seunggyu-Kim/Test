package com.soo.projectboard;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ibatis.sqlmap.client.SqlMapClient;


@Repository("Soo_projectBoardDAO")
public class Soo_projectBoardDAO {

	/*
	 * @Autowired private SqlMapClient sql; //리스트
	 * 
	 * @SuppressWarnings("unchecked") public List<Soo_projectBoardVO>
	 * selectBoardList(Map<String, Object> map) throws Exception {
	 * 
	 * return sql.queryForList("soo_progect1.selectBoardList",map); }
	 */
	
	 @Autowired 
	 private SqlMapClient sql;
	 
	 // QnA List...
	 @SuppressWarnings("unchecked") 
	 public List<Soo_projectBoardVO> BoardList() throws Exception {
		 
	  return sql.queryForList("BoardList");
	 }

	 // QnA Insert
	public String QnAInsert(Soo_projectBoardVO vo) throws Exception{
		
		return (String) sql.insert("QnAInsert",vo);
	}
	
	// QnA View
	public Soo_projectBoardVO QnAview(Long board_seq) throws Exception {

		return (Soo_projectBoardVO) sql.queryForObject("QnAView", board_seq);
	}

	// QnA Remove
	public int remove(Integer board_seq) throws Exception{
		
		return sql.delete("ViewDel",board_seq);
	}

	// QnA update
	public int postupdate(Soo_projectBoardVO vo) throws Exception {
		
		System.out.println("수정 DAO!!!!");
		
		return sql.update("update",vo);
	}

	
	// 페이징 처리 
	@SuppressWarnings("unchecked")
	public List<Soo_projectBoardVO> BoardList(Criteria cri) throws SQLException {

	//	System.out.println("페이징 DAO!!!!!!!!!!!!!!!!");
		
		return sql.queryForList("BoardList",cri);
	}

	
	public int countBoardList() throws Exception{

		//System.out.println("게시글 토탈수 DAO 들어왔다!!!!!");
		
		return (int) sql.queryForObject("countBoardList");
	}
	
	
}

	 
