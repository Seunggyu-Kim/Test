package com.soo.projectboard;

import java.util.List;

import org.springframework.stereotype.Service;

@Service("Soo_projectBoardService")
public interface Soo_projectBoardService {
	
	
	// QnA List
	//List<Soo_projectBoardVO> BoardList() throws Exception;
	
	List<Soo_projectBoardVO> BoardList(Criteria cri) throws Exception;
	
	public int countBoardListTotal() throws Exception;
	
	// QnA Insert
	public String QnAInsert(Soo_projectBoardVO vo) throws Exception;

	// QnA View
	public Soo_projectBoardVO get(Long board_seq) throws Exception;

	//QnA Remove
	public int remove(Integer board_seq) throws Exception;
	
	
	//QnA update
	public int postupdate(Soo_projectBoardVO vo) throws Exception;
	
	//papago
	public String test();

	

}