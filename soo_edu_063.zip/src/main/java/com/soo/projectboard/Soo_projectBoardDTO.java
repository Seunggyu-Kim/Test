package com.soo.projectboard;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Soo_projectBoardDTO {
	
//	private String searchKey;
//	
//	public String getSearchKey() {
//		return searchKey;
//	}
//	public void setSearchKey(String searchKey) {
//		this.searchKey = searchKey;
//	}
	
	private int board_seq;
	private String board_title;
	private String board_writer_name;
	private String board_content_text;
	private Date board_reg_date;
	private Date board_mod_date;
	private String board_notice;
	private String board_img_path;
	private String board_del_yn;
	private int board_type;
	private String board_writer_pass;
	
}


