package com.soo.projectboard;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


/**
 * 게시판 컨트롤러 
 * @author  
 */

@Controller
@RequestMapping("/board/*")
public class Soo_projectBoardController {
	
	@Resource(name = "Soo_projectBoardService")
	private Soo_projectBoardService service;
	
	private static final Logger logger = LoggerFactory.getLogger(Soo_projectBoardController.class);
	

	//리스트
//		@RequestMapping("/soo_project1_Board_list.do")
//		public ModelAndView showBoardList(@RequestParam(defaultValue="title") String searchKey, //기본 검색 옵션값을 제목으로 한다.
//		       							  @RequestParam(defaultValue="") String searchValue,   //searchValue의 기본값을 ""으로 한다
//		         						  @RequestParam(value="pageNo", required=false) String pageNo,
	
	
//		         ModelMap model,Soo_projectBoardVO vo,Map<String, Object> map, HttpSession session) throws Exception {
//			 
//			   ModelAndView mav = new ModelAndView(); //modelAndView 객체화
//			   
//			   logger.debug("Welcome User Home! The client locale is 1.");
//			   logger.info("Welcome User Home! The client locale is 2.");
//			   logger.error("Welcome User Home! The client locale is 3.");
//			   logger.warn("Welcome User Home! The client locale is 4.");
//			   
//			   List<Soo_projectBoardVO> resultList = service.BoardList(map);
//			   
//			   mav.addObject("resultList", resultList);
//			   mav.setViewName("/views/board/Soo_Edu_Board_Notice_List");
//			   
//		      return mav;
//		      
//		}
	
	
	// Papago
	@RequestMapping(value = "/Soo_Edu_API_Papago")
	public String papaGo() throws Exception{
		
		return "views/board/Soo_Edu_API_Papago";
	}
	
	// KakaoPay
	@RequestMapping(value = "/Soo_Edu_API_KakaoPay")
	public String shop() throws Exception{
		
		return "views/board/Soo_Edu_API_KakaoPay";
	}
	
	
	
/**일반고객 관련 컨트롤러 **************************************************************/ 
	
	//QnA_Board List...
//	@RequestMapping(value = "/Soo_Edu_Board_QnA_List")
//	public String Notice_List(Model model) throws Exception{
//		
//		//서비스에서 boardList를 받아서 board 라는 이름으로 데이터를 넘겨준다.
//		List<Soo_projectBoardVO> board = service.BoardList();
//		
//	//	System.out.println("board :"+board);
//		model.addAttribute("board", board);
//		
//		return "views/board/Soo_Edu_Board_QnA_List";
//	}
	
	 
//    @RequestMapping(value="/board/boardList")
//    public ModelAndView openBoardList(CommandMap commandMap) throws Exception {
//        
//        ModelAndView mav = new ModelAndView("/board/boardList");
//        
//        List<Map<String,Object>> list = boardService.selectBoardList(commandMap);
//        mav.addObject("list", list);
//        
//        return mav;

	
	@RequestMapping(value = "/Soo_Edu_Board_QnA_List")
	public ModelAndView Notice_List(Criteria cri) throws Exception{
		
		ModelAndView mav = new ModelAndView("views/board/Soo_Edu_Board_QnA_List");
		
		PageMaker pageMaker = new PageMaker();
	    pageMaker.setCri(cri);
		pageMaker.setTotalCount(service.countBoardListTotal());

		List<Soo_projectBoardVO> board = service.BoardList(cri);
		
		mav.addObject("board", board);
		mav.addObject("pageMaker", pageMaker);

		//System.out.println("페이징처리중입니다.");
		
		return mav;
		
	}
	
//	@RequestMapping(value = "/Soo_Edu_Board_QnA_List")
//	public ModelAndView Notice_List(Criteria cri) throws Exception{
//		
//		 ModelAndView mav = new ModelAndView("/Soo_Edu_Board_QnA_List");
//		 
//		   PageMaker pageMaker = new PageMaker();
//		   pageMaker.setCri(cri);
//		   pageMaker.setTotalCount(100);
//		 
//		 List<Soo_projectBoardVO> board = service.BoardList(cri);
//		
//		 mav.addObject("board", board);
//		 mav.addObject("pageMaker", pageMaker);
//		 
//		 System.out.println("페이징 컨트롤러 ");
//		 
//		 return mav;
//		
//	}
	
	//QnA Insert 작성페이지 컨트롤러
	@RequestMapping(value = "/Soo_Edu_Board_QnA_Insert")
	public String QnAInsert() throws Exception{
		
		return "views/board/Soo_Edu_Board_QnA_Insert";
	}
	
	
	// QnA Insert 작성후 컨트롤러
	// @RequestParam으로 변경해볼것.. 
	@RequestMapping(value = "/Soo_Edu_Board_QnA_Insert.do")
	public String QnAInsertdo(HttpServletRequest request) throws Exception{
		
		String board_writer_name=request.getParameter("board_writer_name");
		String board_title=request.getParameter("board_title");
		String board_content_text=request.getParameter("board_content_text");
		String board_img_path=request.getParameter("board_img_path");
		String board_writer_pass=request.getParameter("board_writer_pass");
	
		Soo_projectBoardVO vo = new Soo_projectBoardVO();
		
		vo.setBoard_writer_name(board_writer_name);
		vo.setBoard_title(board_title);
		vo.setBoard_content_text(board_content_text);
		vo.setBoard_img_path(board_img_path);
		vo.setBoard_writer_pass(board_writer_pass);

		service.QnAInsert(vo);

		return "redirect:Soo_Edu_Board_QnA_List";
	}

	// QnA_Board 상세페이지
	@RequestMapping(value = "/Soo_Edu_Board_QnA_View")
	public String QnA_View(Model model,  @RequestParam("board_seq") Long board_seq) throws Exception{
	
		//서비스에서 board_seq를 받아서 view라는 이름으로 데이터를 넘겨준다.
		model.addAttribute("view",service.get(board_seq)); 
		
		return "views/board/Soo_Edu_Board_QnA_View";
	}
	
	
	  // QnA 수정 페이지 진입..
	  @RequestMapping(value = "/Soo_Edu_Board_QnA_ViewDetails") 
	  public String update(Model model, @RequestParam("board_seq") Long board_seq) throws Exception{
	  
	  //서비스에서 board_seq를 받아서 view라는 이름으로 데이터를 넘겨준다.
	  model.addAttribute("view",service.get(board_seq));
	//  System.out.println("수정 겟!!!!");
	  return "views/board/Soo_Edu_Board_QnA_ViewDetails"; 
	  
	  }
	 
	  // QnA 수정 작업... 
	  @RequestMapping(value = "/Soo_Edu_Board_QnA_ViewDetails.do", method=RequestMethod.POST) 
	  public Object postupdate(Soo_projectBoardVO vo, RedirectAttributes rttr) throws Exception{
		  
		  System.out.println("수정 포스트!!!asdasd! "+ vo);
		   int res = service.postupdate(vo);
			
			if(res != 0 ) {
				System.out.println("성공");
				
			}else {
				System.out.println("실패");
			
	}	
			
			return "redirect:Soo_Edu_Board_QnA_List";			
		  
}
	  
	// remove 메소드 추가 GET 방식으로 구현
	@RequestMapping(value = "/Soo_Edu_Board_QnA_remove", method = RequestMethod.GET)
	public String remove(@RequestParam("board_seq") Integer board_seq, RedirectAttributes rttr) throws Exception {
		
	//	System.out.println("remove");
		
		service.remove(board_seq);
		rttr.addFlashAttribute("result", "removeOK");
		
		return "redirect:Soo_Edu_Board_QnA_List";
	}
	
/**일반고객 관련 컨트롤러 **/ 	
	
	// 관리자 글쓰기 Insert
	@RequestMapping(value = "/Soo_Edu_Board_Notice_Insert")
	public String Notice_Insert() throws Exception{
		
	//	System.out.println("-------관리자 글쓰기 화면------");
		
		return "views/board/Soo_Edu_Board_Notice_Insert";
	}
	
	
//	@RequestMapping(value = "/uploadForm")
//	public String uploadForm() {
//
//		System.out.println("upload form");
//
//		return "views/uploadForm";
//
//	}
	 
	
	@RequestMapping(value="/uploadFormAction", method = RequestMethod.POST)
	
	public String uploadFormPost(MultipartFile[] uploadFile, Model model) {
		
		for(MultipartFile multipartFile : uploadFile) {
			
			System.out.println("---------------------------");
			System.out.println("Upload File Name: " +multipartFile.getOriginalFilename());
			System.out.println("Upload File Size: " +multipartFile.getSize());
		}
		
		return null;
		
	}
	
	@RequestMapping(value = "/papago")
	public String papago(Model model) throws Exception{

		
			String test = service.test();
			
			model.addAttribute("message", test);
		
		System.out.println("파파고..");

		return "views/board/papago";

	}
	
	
	
}

	
	
	
	
	