package com.soo.projectboard;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Soo_projectBoardVO {

	
	private int board_seq;
	private String board_title;
	private String board_writer_name;
	private String board_content_text;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date board_reg_date;
	
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date board_mod_date;
	
	private String board_notice;
	private String board_img_path;
	private String board_del_yn;
	private int board_type;
	private String board_writer_pass;

}


