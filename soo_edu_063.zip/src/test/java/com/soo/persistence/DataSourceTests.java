package com.soo.persistence;

import static org.junit.Assert.fail;

import java.sql.Connection;
import java.sql.DriverManager;

import org.junit.Test;

import lombok.extern.log4j.Log4j;

@Log4j
public class DataSourceTests {
	
	static {
		try {
			 Class.forName("org.mariadb.jdbc.Driver");
		}	catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public void testConnection() {
		
		try(Connection con=
			DriverManager.getConnection(
		         "jdbc:mariadb://125.141.105.89:3306/soo_edu_063",
		          "root",
		          "difficultMariaRoot#12")){
			
			log.info(con);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	
	}	
}
	